package com.jellied.ultrafox;

import com.fox2code.foxloader.loader.ServerMod;

public class UltrafoxServer extends Ultrafox implements ServerMod {
}
