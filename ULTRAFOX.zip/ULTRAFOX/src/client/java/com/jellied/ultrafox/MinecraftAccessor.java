package com.jellied.ultrafox;

public interface MinecraftAccessor {
    public int getFreezeFrameTicks();
    public void incrementFreezeFrameTicks(int amount);
}
