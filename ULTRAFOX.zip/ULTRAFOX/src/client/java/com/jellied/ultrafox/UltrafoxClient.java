package com.jellied.ultrafox;

import com.fox2code.foxloader.loader.ClientMod;

public class UltrafoxClient extends Ultrafox implements ClientMod {
}
