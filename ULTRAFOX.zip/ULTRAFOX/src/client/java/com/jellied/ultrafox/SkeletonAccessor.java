package com.jellied.ultrafox;

public interface SkeletonAccessor {
    void setIsDynamiteSkeleton(boolean set);
    boolean getIsDynamiteSkeleton();
}
