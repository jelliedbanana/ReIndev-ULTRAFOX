package com.jellied.ultrafox;

import com.fox2code.foxloader.loader.Mod;

public class Ultrafox extends Mod {
}
